/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_222()
{
    return 3284633928U;
}

void setval_212(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_214()
{
    return 2425393496U;
}

void setval_252(unsigned *p)
{
    *p = 2445773128U;
}

void setval_495(unsigned *p)
{
    *p = 3284633920U;
}

unsigned getval_153()
{
    return 616796376U;
}

unsigned addval_157(unsigned x)
{
    return x + 2421728749U;
}

void setval_451(unsigned *p)
{
    *p = 3277364655U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_289(unsigned *p)
{
    *p = 2425405849U;
}

void setval_478(unsigned *p)
{
    *p = 3821259401U;
}

unsigned addval_483(unsigned x)
{
    return x + 3526940289U;
}

unsigned addval_178(unsigned x)
{
    return x + 3674784137U;
}

unsigned getval_101()
{
    return 3767093434U;
}

unsigned addval_216(unsigned x)
{
    return x + 3229931145U;
}

unsigned addval_304(unsigned x)
{
    return x + 3674784169U;
}

unsigned addval_257(unsigned x)
{
    return x + 3680551305U;
}

unsigned getval_326()
{
    return 3599351373U;
}

unsigned addval_259(unsigned x)
{
    return x + 2425408136U;
}

void setval_413(unsigned *p)
{
    *p = 3380923016U;
}

unsigned addval_255(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_172(unsigned x)
{
    return x + 3375939969U;
}

unsigned getval_203()
{
    return 3281043853U;
}

void setval_448(unsigned *p)
{
    *p = 2425539209U;
}

unsigned getval_376()
{
    return 3767126244U;
}

unsigned addval_309(unsigned x)
{
    return x + 3286272360U;
}

unsigned getval_190()
{
    return 3281114761U;
}

void setval_455(unsigned *p)
{
    *p = 3675838089U;
}

unsigned getval_486()
{
    return 2430634824U;
}

unsigned addval_394(unsigned x)
{
    return x + 3281049097U;
}

void setval_273(unsigned *p)
{
    *p = 3767093291U;
}

void setval_464(unsigned *p)
{
    *p = 3676357001U;
}

unsigned addval_350(unsigned x)
{
    return x + 3532966537U;
}

void setval_351(unsigned *p)
{
    *p = 3224947337U;
}

unsigned addval_296(unsigned x)
{
    return x + 2430634328U;
}

unsigned getval_392()
{
    return 2446756278U;
}

unsigned getval_125()
{
    return 3767094317U;
}

unsigned getval_362()
{
    return 3525364425U;
}

unsigned getval_151()
{
    return 3374369421U;
}

unsigned getval_410()
{
    return 3232028297U;
}

unsigned addval_417(unsigned x)
{
    return x + 3531129225U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
